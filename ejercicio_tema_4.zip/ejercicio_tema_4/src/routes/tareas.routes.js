app.get('/recurso', handler);      // Obtener
app.post('/recurso', handler);     // Crear
app.put('/recurso/:id', handler);  // Reemplazar
app.patch('/recurso/:id', handler);// Modificar parcialmente
app.delete('/recurso/:id', handler);// Eliminar
app.all('/recurso', handler);      // Todos los métodos